def main():
    print("Hello from mcp-client!")


if __name__ == "__main__":
    main()
