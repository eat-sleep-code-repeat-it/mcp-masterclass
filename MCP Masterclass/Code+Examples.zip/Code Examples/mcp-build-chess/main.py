def main():
    print("Hello from mcp-build-product-hunt!")


if __name__ == "__main__":
    main()
