def main():
    print("Hello from mcp-build-client-agent-airbnb-memory!")


if __name__ == "__main__":
    main()
