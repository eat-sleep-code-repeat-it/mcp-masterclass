def main():
    print("Hello from mcp-server-deepdive-deployment!")


if __name__ == "__main__":
    main()
