def main():
    print("Hello from client!")


if __name__ == "__main__":
    main()
