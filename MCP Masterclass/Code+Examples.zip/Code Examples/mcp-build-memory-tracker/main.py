def main():
    print("Hello from mcp-build-memory-tracker!")


if __name__ == "__main__":
    main()
