def main():
    print("Hello from mcp-primitives-and-inputs!")


if __name__ == "__main__":
    main()
