def main():
    print("Hello from mcp-server-http-streamable-updated!")


if __name__ == "__main__":
    main()
