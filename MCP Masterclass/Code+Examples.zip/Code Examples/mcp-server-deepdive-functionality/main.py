def main():
    print("Hello from mcp-server-deepdive-functionality!")


if __name__ == "__main__":
    main()
